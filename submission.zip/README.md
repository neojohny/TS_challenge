# TS_challenge
In this project, a two-year transaction history data from merchant was given to achieve two goals. The first is merchant segmentation and the second is customer churn prediction.
### Feature Engineering
* TSFresh
* Experience
### Clustering
* visualization
* Hyper-parameter tuning
* Center explain
### Churn Definition and Identify
* Empirical and Theoretical
### Supervised Learning to Predict Churn
* Model selection
* HP tuning
* Reasoning for churn
* Approach to handle the churn
